#include <stdio.h>
#include <math.h>
#include <string.h>

double quesA(double x);
double quesB(double x);
double quesC(double x);
double quesD(double x);

void distance(double minX, double maxX, double e);
void absolute(double minX, double maxX, double e);
void relative(double minX, double maxX, double e);


int main() {

    double min = 0, max = 0, e = 0;
    char type[100] = "";

    printf("SECTION 2.1 EXECISE 6 D.\n\n");

    printf("Please enter the start of the root search interval as a real value:");
    scanf("%lf", &min);

    printf("Please enter the end of the root search interval as a real value:");
    scanf("%lf", &max);

    printf("Please enter the the stopping criterion as a character array:\nDISTANCE_TO_ROOT,\nABSOLUTE_ERROR,\nRELATIVE_ERROR\n\n");
    scanf("%s", type);

    printf("Please enter the epsilon value:");
    scanf("%lf", &e);

    if(strcmp(type, "DISTANCE_TO_ROOT") == 0)
        distance(min, max, e);
    else if(strcmp(type, "ABSOLUTE_ERROR") == 0)
        absolute(min, max, e);
    else if(strcmp(type, "RELATIVE_ERROR") == 0)
        relative(min, max, e);
    else
        printf("SYNTAX ERROR\n");

    return 0;
}

double quesA(double x){
    double res = 0;
    res = 3*x;
    res = res - exp(x);

    return res;
}

double quesB(double x){
    double res = 0;
    res = 2 * x;
    res += 3*cos(x);
    res -= exp(x);
    return res;
}

double quesC(double x){
    double res = 0;
    res = pow(x,2);
    res -= 4 * x;
    res += 4;
    res -= log(x);
    return res;
}

double quesD(double x){
    double res = 0;
    res = x + 1;
    res -= 2 * sin(M_PI);
    return res;
}

void distance(double minX, double maxX, double e){
    double minY = 0, maxY = 0;
    double midX = 0, midY = 0;
    int i = 0;

    minY = quesD(minX);
    maxY = quesD(maxX);

    if(minY > 0 && maxY > 0){
        printf("There is no root in this search interval.\n");
        return;
    }
    else if(minY < 0 && maxY < 0){
        printf("There is no root in this search interval.\n");
        return;
    }

    if(fabs(minY) < e){
        printf("Root: %f\n", minX);    
    }
    else if(fabs(maxY) < e){
        printf("Root: %f\n", maxX);    
    }

    midX = (minX + maxX) / 2;
    midY = quesD(midX);
    printf("%d      %lf\n", i, midY);

    for(i = 1; i < 100 && fabs(midY) > e; ++i){        
        if(minY < 0 ){
            if(midY < 0){
                minX = midX;
                minY = quesD(minX);        
            }
            else{
                maxX = midX;
                maxY = quesD(maxX);
            }
        }
        else if(minY > 0){
            if(midY > 0){
                minX = midX;
                minY = quesD(minX);
            }
            else{
                maxX = midX;
                maxY = quesD(maxX);
            }
        }

        midX = (minX + maxX) / 2;
        midY = quesD(midX);

        printf("%d      %lf\n", i, midY);
    }

    if( i < 100){
        printf("Root: %f\n", midX);
        return;
    }
    else{
        printf("Kok 100 tekrarda bulunamadi.\n");
    }
    return;
}

void absolute(double minX, double maxX, double e){
    double minY = 0, maxY = 0;
    double midX = 0, midY = 0;
    double midBefX = 0, midBefY = 0;
    double langer = 999;
    int i = 0;

    minY = quesD(minX);
    maxY = quesD(maxX);

    if(minY > 0 && maxY > 0){
        printf("There is no root in this search interval.\n");
        return;
    }
    else if(minY < 0 && maxY < 0){
        printf("There is no root in this search interval.\n");
        return;
    }
    
    if(fabs(minY) < e){
        printf("Root: %f\n", minX);    
    }
    else if(fabs(maxY) < e){
        printf("Root: %f\n", maxX);    
    }

    midX = (minX + maxX) / 2;
    midY = quesD(midX);

    if(minY < 0 ){
        if(midY < 0){
            minX = midX;
            minY = quesD(minX);               
        }
        else{
            maxX = midX;
            maxY = quesD(maxX);
        }
    }
    else if(minY > 0){
        if(midY > 0){
            minX = midX;
            minY = quesD(minX);
        }
        else{
            maxX = midX;
            maxY = quesD(maxX);
        }
    }

    midBefX = midX;
    midBefY = midY;
    midX = (minX + maxX) / 2;
    midY = quesD(midX);
    langer = fabs(midX - midBefX);

    for(i = 2; i < 100 && langer > e; ++i){

        if(minY < 0 ){
            if(midY < 0){
                minX = midX;
                minY = quesD(minX);               
            }
            else{
                maxX = midX;
                maxY = quesD(maxX);
            }
        }
        else if(minY > 0){
            if(midY > 0){
                minX = midX;
                minY = quesD(minX);
            }
            else{
                maxX = midX;
                maxY = quesD(maxX);
            }
        }
        midBefX = midX;
        midBefY = midY;
        midX = (minX + maxX) / 2;
        midY = quesD(midX);

        langer = fabs(midX-midBefX);
        printf("%d      %lf\n", i, midY);
    }

    if( i < 100){
        printf("Root: %f\n", midX);
        return;
    }
    else{
        printf("Kok 100 tekrarda bulunamadi.\n");
    }
    return;
}

void relative(double minX, double maxX, double e){
    double minY = 0, maxY = 0;
    double midX = 0, midY = 0;
    double midBefX = 0, midBefY = 0;
    double langer = 999;
    int i = 0;

    minY = quesD(minX);
    maxY = quesD(maxX);

    if(minY > 0 && maxY > 0){
        printf("There is no root in this search interval.\n");
        return;
    }
    else if(minY < 0 && maxY < 0){
        printf("There is no root in this search interval.\n");
        return;
    }
    
    if(fabs(minY) < e){
        printf("Root: %f\n", minX);    
    }
    else if(fabs(maxY) < e){
        printf("Root: %f\n", maxX);    
    }

    midX = (minX + maxX) / 2;
    midY = quesD(midX);

    if(minY < 0 ){
        if(midY < 0){
            minX = midX;
            minY = quesD(minX);               
        }
        else{
            maxX = midX;
            maxY = quesD(maxX);
        }
    }
    else if(minY > 0){
        if(midY > 0){
            minX = midX;
            minY = quesD(minX);
        }
        else{
            maxX = midX;
            maxY = quesD(maxX);
        }
    }

    midBefX = midX;
    midBefY = midY;
    midX = (minX + maxX) / 2;
    midY = quesD(midX);
    langer = fabs(midX - midBefX);
    langer = langer / fabs(midX);

    for(i = 2; i < 100 && langer > e; ++i){

        if(minY < 0 ){
            if(midY < 0){
                minX = midX;
                minY = quesD(minX);               
            }
            else{
                maxX = midX;
                maxY = quesD(maxX);
            }
        }
        else if(minY > 0){
            if(midY > 0){
                minX = midX;
                minY = quesD(minX);
            }
            else{
                maxX = midX;
                maxY = quesD(maxX);
            }
        }
        midBefX = midX;
        midBefY = midY;
        midX = (minX + maxX) / 2;
        midY = quesD(midX);

        langer = fabs(midX-midBefX);
        langer = langer / fabs(midX);
        printf("%d      %lf\n", i, midY);
    }

    if( i < 100){
        printf("Root: %f\n", midX);
        return;
    }
    else{
        printf("Kok 100 tekrarda bulunamadi.\n");
    }
    return;
}
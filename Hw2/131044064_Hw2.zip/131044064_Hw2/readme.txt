-i JCB flagi verildiğinde istenen problemin jacobi metodu ile çözülmesi implement edilmedi bu nedenle sadece -i GESP flagi ile gaussian metodu kullanılarak problem çözümlenebilmektedir.

Ödevde çözülmesi istenen sorular soru ismi oluşturulmuş input dosyaları ile çözülebilir.
6.2-1c.txt
7.3-1a.txt
7.3-1b.txt

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

double solveWithGESP(double** matrix, int row, int col, double* results);

double solveWithJCB(double** matrix, int row, int col, double* results);

/*verilen iki boyutlu row satirli all matrisinde 
**colFind sutununun pivot degerini bulur ve 
**satirlari duzenler
*/
void findPivot(double** all, int col, int row,int colFind);


double findRowMax(double** all, int col, int row);

void changeRows(double** m, int col, int row1, int row2);

int main(int argc, char const *argv[]) {

    const char *filename = argv[2];
    const char *solveMode = argv[4];

    FILE *file = fopen(filename, "r");

    double** matrix;
    double* roots;

    char tmp = ' ';
    int col = 1;
    int row = 1;

    while(tmp != '\n'){
        fscanf(file, "%c", &tmp);
        if(tmp == ',')
            ++col;
    }
    while(tmp != EOF){
        tmp = (char)  fgetc(file);
        
        if(tmp == '\n')
            ++row;
    }

    matrix = (double**) malloc(row*sizeof(double*));
    for(int i = 0; i < row; ++i){
        matrix[i] = (double*)malloc(col*sizeof(double));
    }

    roots = (double*)malloc((col-1)*sizeof(double));

    fseek(file, 0, SEEK_SET);

    int i = 0;
    int j = 0;
    tmp = ' ';
    while(tmp != EOF){
        fscanf(file,"%lf", &matrix[i][j]);
        tmp = (char) fgetc(file);
        ++j;
        if(tmp == '\n'){
            ++i;
            j = 0;
        }
    }

    
    if(strcmp("GESP", solveMode) == 0)
        solveWithGESP(matrix, row, col, roots);
    else if(strcmp("JCB", solveMode) == 0)
        solveWithJCB(matrix, row, col, roots);
    else{
    	printf("Syntax error. Use JCB or GESP flags.\n");
    	return 0;
    }



    for(int i = 0; i < col; ++i){
        printf("x%d = %lf\n", i, roots[i]);
    }
    for( i = 0; i < row; ++i)
        free(matrix[i]);
    free(matrix);
    free(roots);
    return 0;
}

double solveWithGESP(double** matrix, int row, int col, double* results){

    double a;

    for(int i = 0; i < col-1; ++i){
        findPivot(matrix, col, row, i);
        for(int j = i+1; j < row; ++j){  
            a = matrix[j][i]/matrix[i][i];
            for(int k = 0; k < col; ++k){
                matrix[j][k] = matrix[j][k] - a*matrix[i][k];                
            }
        }
    }

    for(int i = row-1; i >= 0; --i){
        int sum = 0;
        for(int j = i+1; j <col-2; ++j){
            sum += (results[j]*matrix[i][j]);
        }
        results[i] = (matrix[i][col-1] - sum) / matrix[i][i];
    }

    return 0;
}

void findPivot(double** all, int col, int row, int colFind){
    double* maxRows = (double*)malloc(row*sizeof(double));
    double maxPiv;
    int pivRow;

    for(int i = colFind; i < row; ++i)
        maxRows[i] = findRowMax(all, col, i);

    pivRow = colFind;
    maxPiv = fabs(all[colFind][colFind] / maxRows[colFind]);

    for(int i = colFind+1; i < row; ++i){
        if(fabs(all[i][colFind] / maxRows[i]) > maxPiv){
            pivRow = i;
            maxPiv = all[i][colFind];
        }
    }

    if(colFind != maxPiv)
        changeRows(all, col, colFind, maxPiv);
    
    free(maxRows);
}

double findRowMax(double** all, int col, int row){
    double max = 0;
    for(int i = row; i < col-1; ++i)
        if(fabs(all[row][i]) > max)
            max = fabs(all[row][i]);

    return max;
}

void changeRows(double** m, int col, int row1, int row2){
    double tmp;
    for(int i = 0; i < col; i++){
        tmp = m[row1][i];
        m[row1][i] = m[row2][i];
        m[row2][i] = tmp;
    }
    return;
}

double solveWithJCB(double** matrix, int row, int col, double* results){
    printf("Implement edilmedi.\n");
    return 0;
}